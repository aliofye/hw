package edu.buffalo.cse.cse486586.groupmessenger1;

import android.app.Activity;
import android.content.ContentValues;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {
    // define remote ports for each avd
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    // define serve port
    static final int SERVER_PORT = 10000;
    // init sequence
    static int sequence = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        try {
            // execute ServerTask()
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.e(getClass().getSimpleName(), "Can't create a ServerSocket");
            return;
        }


        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        final TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        
        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        
        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */
        final EditText et = (EditText) findViewById(R.id.editText1);
        findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = et.getText().toString();
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, message, REMOTE_PORT0);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, message, REMOTE_PORT1);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, message, REMOTE_PORT2);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, message, REMOTE_PORT3);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, message, REMOTE_PORT4);
                //test if the button works
                tv.setText(message);
                //clear edit text
                et.setText("");
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }

    /*code from PA1*/
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            Socket clientSocket = null;
            InputStream is = null;
            DataInputStream dis = null;
            try {
                //a while loop to handle multiple messages
                while (true) {
                    // server accepts connection from client
                    clientSocket = serverSocket.accept();
                    //get input stream from client socket
                    is = clientSocket.getInputStream();
                    //read the input stream as data, in our case, as a String
                    dis = new DataInputStream(is);
                    //readUTF() reads the String from the DataInputStream and return a String
                    //the String here is our message sent from the client
                    String msg = dis.readUTF();
                    //pass the message to onProgressUpdate() to update TextViews
                    publishProgress(msg);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                //clean up
                try {
                    if (is != null) is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    if (dis != null) dis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    if (clientSocket != null) clientSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    if (serverSocket != null) serverSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return null;
        }

        protected void onProgressUpdate(String... strings) {
            //insert messages to database
            String message = strings[0];

            ContentValues keyValueToInsert = new ContentValues();
            //add key as sequence number then increment the key
            keyValueToInsert.put("key", String.valueOf(sequence++));
            keyValueToInsert.put("value", message);
            //get to content provider uri
            Uri contentProviderUri = Uri.parse("content://edu.buffalo.cse.cse486586.groupmessenger1.provider");
            //insert to "database"
            getContentResolver().insert(contentProviderUri, keyValueToInsert);
        }
    }

    /* code from PA1 */
    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {
            Socket socket = null;
            OutputStream os = null;
            DataOutputStream dos = null;
            try {
                String remotePort = msgs[1];

                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(remotePort));

                String msgToSend = msgs[0];
                Log.e(getClass().getSimpleName(), msgToSend);
                /*
                 * TODO: Fill in your client code that sends out a message.
                 */
                //set output stream of socket to send message to server
                os = socket.getOutputStream();
                //send it out as data, or a String in our case
                dos = new DataOutputStream(os);
                //write the string as UTF to be received by readUTF() on the server side
                dos.writeUTF(msgToSend);

            } catch (UnknownHostException e) {
                Log.e(getClass().getSimpleName(), "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e(getClass().getSimpleName(), "ClientTask socket IOException");
            }

            return null;
        }
    }
}
