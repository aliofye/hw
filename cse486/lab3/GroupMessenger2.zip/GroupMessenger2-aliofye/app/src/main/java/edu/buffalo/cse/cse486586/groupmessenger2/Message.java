package edu.buffalo.cse.cse486586.groupmessenger2;

import java.io.Serializable;

/*
    * Message class that is used in the priority queue, it encapsulates all the necessary
    * methods for messages
    * */
public class Message implements Serializable {
    public String port;
    public String message;
    public int priority;

    /*
    * public constructor
    * @param port sets the port from which the message originated
    * @param priority sets the priority in which the message was received
    * */
    public Message(String port, String message) {
        this.port = port;
        this.message = message;
        this.priority = Integer.MIN_VALUE;
    }

    public String getPort() {
        return port;
    }

    public String getMessage() {
        return message;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}
