package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Comparator;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 *
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {
    // define remote ports for each avd
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    // define serve port
    static final int SERVER_PORT = 10000;
    // init current port
    private static String clientPort;
    // init sequence
    private static AtomicInteger sequence = new AtomicInteger(0);
    // declare PriorityQueue for FIFO ordering
    private static PriorityBlockingQueue<Message> messageQueue = new PriorityBlockingQueue<Message>(50, new Comparator<Message>() {
        @Override
        public int compare(Message one, Message two) {
            if(one.getPriority() > two.getPriority()){
                return 1;
            } else {
                return -1;
            }
        }
    });



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        /* hack from PA1 to get port number */
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        clientPort = String.valueOf(Integer.parseInt(portStr) * 2);

        try {
            // execute ServerTask()
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.e(getClass().getSimpleName(), "Can't create a ServerSocket");
            return;
        }


        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        final TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());

        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));

        /*
         code from PA2
         */
        final EditText et = (EditText) findViewById(R.id.editText1);
        findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // prepare message
                String text = et.getText().toString();
                String order = Integer.toString(Integer.MIN_VALUE);
                Message message = new Message(clientPort, text);
                messageQueue.put(message);

                //test if the button works
                tv.setText(text);
                //clear edit text
                et.setText("");
                // execute client task
                new ClientTask()
                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, clientPort, text, order, REMOTE_PORT0);
                new ClientTask()
                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, clientPort, text, order, REMOTE_PORT1);
                new ClientTask()
                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, clientPort, text, order, REMOTE_PORT2);
                new ClientTask()
                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, clientPort, text, order, REMOTE_PORT3);
                new ClientTask()
                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, clientPort, text, order, REMOTE_PORT4);

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }

    /*code from PA1*/
    private class ServerTask extends AsyncTask<ServerSocket, Message, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            Socket clientSocket = null;
            //refrence: https://docs.oracle.com/javase/7/docs/api/java/io/ObjectInputStream.html
            ObjectInputStream ois = null;
            try {
                //a while loop to handle multiple messages
                while (true) {
                    // server accepts connection from client
                    clientSocket = serverSocket.accept();
                    clientSocket.setSoTimeout(5000);

                    //get input stream from client socket
                    //read the input stream as data, in our case, as a String
                    ois = new ObjectInputStream(clientSocket.getInputStream());
                    //get Message from ObjectInputStream
                    final Message message = (Message) ois.readObject();
                    // check if not sequencer and priority is not step
                    if (!clientPort.equals(REMOTE_PORT0) && message.getPriority() == Integer.MIN_VALUE) {
                        Log.e("msgerr", "sequencer skip");
                        continue;
                    }
                    // sequencer step
                    if(message.getPriority() == Integer.MIN_VALUE){
                        Log.e("msgerr", "updating sequence");
                        Log.e("msgerr", "Sequence before: " + message.getPriority());
                        message.setPriority(sequence.intValue());
                        sequence.getAndIncrement();
                        Log.e("msgerr", "Sequence after: " + message.getPriority());
                        final String TEXT = message.getMessage();
                        final String ORDER = Integer.toString(message.getPriority());
                        final String ORIGIN = message.getPort();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT0);
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT1);
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT2);
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT3);
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT4);
                            }
                        });
                        // other clients step
                    } else {
                        publishProgress(message);
                        if (message.getPort().equals(clientPort)) {
                            messageQueue.take();
                            if (!messageQueue.isEmpty()) {
                                Log.e("msgerr", "emptying queue");
                                Message newMessage = messageQueue.peek();
                                final String TEXT = newMessage.getMessage();
                                final String ORDER = Integer.toString(newMessage.getPriority());
                                final String ORIGIN = newMessage.getPort();
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT0);
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT1);
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT2);
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT3);
                                new ClientTask()
                                        .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, ORIGIN, TEXT, ORDER, REMOTE_PORT4);
                            }
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return null;
        }

        protected void onProgressUpdate(Message ... messages) {
            Message message = messages[0];
            Log.e("msgerr", "Queue Size: " + messageQueue.size());
            //insert messages to database
            Log.e("msgerr", "Origin: " + message.getPort());
            Log.e("msgerr", "Message: " + message.getMessage());
            Log.e("msgerr", "Order: " + message.getPriority());
            ContentValues keyValueToInsert = new ContentValues();
            //add key as sequence number then increment the key
            keyValueToInsert.put("key", message.getPriority());
            keyValueToInsert.put("value", message.getMessage());
            //get to content provider uri
            Uri contentProviderUri = Uri.parse("content://edu.buffalo.cse.cse486586.groupmessenger2.provider");
            //insert to "database"
            getContentResolver().insert(contentProviderUri, keyValueToInsert);
        }
    }

    /* code from PA1 */
    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... args) {
            Socket socket;
            ObjectOutputStream oos;
            try {
                //prepare message
                String originPort = args[0];
                String msg = args[1];
                int order = Integer.parseInt(args[2]);
                Message message = new Message(originPort, msg);
                message.setPriority(order);
                //send out
                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(args[3]));
                socket.setSoTimeout(5000);
                //set output stream of socket to send message to server
                oos = new ObjectOutputStream(socket.getOutputStream());
                oos.writeObject(message);

            } catch (UnknownHostException e) {
                e.printStackTrace();
                Log.e(getClass().getSimpleName(), "ClientTask UnknownHostException");
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(getClass().getSimpleName(), "ClientTask socket IOException");
            }
            return null;
        }
    }
}
