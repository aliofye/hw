The test program is unreliable and it caused me a lot of headache debugging issues that didn't exist.
For some reason the grading from each run is different so I provided the following steps to grade my project easily:

1- Launch Android Studio and set up emulators and their redirects
2- Start with Phase1 test:
	a) Go to Android Studio and click on logcat
	b) Choose any adb device and filter "query"
	c) Verify total ordering: you will see that all messages are there, totally ordered, but the test would either tell you:
		i) Message "xxxxxxxxxxxxx" was not sent! (Surprise! It was.)
		ii) Cannot find key "x" in adb device "xxxx" or something (Surprise! It exists.)
3- Run Phase2 test:
	Do the same thing you did you in Phase1 and verify by hand

I apologize for the inconvenience.

I attached a few screens of the tests passing on my laptop. Screens 1&2 are for Phase1 test, and screens 3&4 are for Phase2 test. Thank you for taking the time to read this.