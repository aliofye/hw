package edu.buffalo.cse.cse486586.simpledht;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;

public class SimpleDhtProvider extends ContentProvider {
    private final String REMOTE_PORT0 = "11108";
    private final Uri URI = Uri.parse("content://edu.buffalo.cse.cse486586.simpledht.provider");
    private final String KEY_FIELD = "key";
    private final String VALUE_FIELD = "value";
    private static RoutingTable table;
    private static Cursor regularQuery;
    private static HashMap<String, String> globalQuery;
    private final Object lock = new Object();

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

        // if key lies between successor and predecessor nodes
        if (selection.equals("\"@\"") || selection.equals("@")) {
            deleteAllFromStorage();
        } else if (selection.equals("\"*\"") || selection.equals("*")) {
            if (deleteAllFromStorage()) {
                // send to successor
                final String ORIGIN = getClientPort();
                final String REMOTE = getTable().getSuccessor().port;
                synchronized (lock) {
                    try {
                        lock.wait();
                        Log.e("lock", "Grabbing lock!");
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                Log.e("lock", "Lock has been released!");
                Request request = new Request(ORIGIN, REMOTE, "DELETE_ALL", null, null, null, null);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, request);
            }
        } else {
            if (isPartition(getClientId(), selection)) {
                deleteFromStorage(selection);
            } else {
                // send to successor
                final String ORIGIN = getClientPort();
                final String REMOTE = getTable().getSuccessor().port;
                Request request = new Request(ORIGIN, REMOTE, "DELETE", selection, null, null, null);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, request);
            }
        }

        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // get key and value from ContentValues
        String key = values.getAsString("key");
        String value = values.getAsString("value");
        // if key lies between successor and predecessor nodes
        if (isPartition(getClientId(), key)) {
            writeToStorage(key, value);
        } else {
            // send to successor
            final String ORIGIN = getClientPort();
            final String REMOTE = getTable().getSuccessor().port;
            Request request = new Request(ORIGIN, REMOTE, "INSERT", key, value, null, null);
            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, request);
        }
        return uri;
    }

    @Override
    public boolean onCreate() {

        try {
            // execute ServerTask()
            final int SERVER_PORT = 10000;
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

            // generate hash and add to routing table
            String id = getClientId();
            String port = getClientPort();
            table = new RoutingTable(port);
            try {
                String hash = genHash(id);
                Tuple tuple = new Tuple(id, port, hash);
                table.add(tuple);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }

            // if not first emulator, send join request
            if (!port.equals(REMOTE_PORT0)) {
                Request request = new Request(port, REMOTE_PORT0, "JOIN_REQUEST", null, null, getTable(), null);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, request);
            }
        } catch (IOException e) {
            Log.e(getClass().getSimpleName(), "Server not operational");
        }
        return false;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {

        if (selection.equals("\"@\"") || selection.equals("@")) {
            Cursor query = queryAllFromStorage();
            Log.e("fileio", "Local Query");
            print(query);
            return query;
        } else if (selection.equals("\"*\"") || selection.equals("*")) {
            // send to successor
            final String ORIGIN = getClientPort();
            final String REMOTE = getTable().getSuccessor().port;
            // base case
            synchronized (lock) {
                Request request = new Request(ORIGIN, REMOTE, "QUERY_ALL", null, null, null, globalQuery);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, request);
                try {
                    lock.wait();
                    Log.e("lock", "Grabbing lock!");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            Cursor query = hashMapToCursor(globalQuery);
            Log.e("fileio", "Global Query");
            Log.e("lock", "Lock has been released!");
            print(query);
            return query;
        } else {
            if (isPartition(getClientId(), selection)) {
                return queryFromStorage(selection);
            } else {
                // send to successor
                final String ORIGIN = getClientPort();
                final String REMOTE = getPartition(selection);

                synchronized (lock) {
                    Request request = new Request(ORIGIN, REMOTE, "QUERY", selection, null, null, null);
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, request);
                    try {
                        lock.wait();
                        Log.e("lock", "Grabbing lock!");
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                Log.e("fileio", "Regular Query");
                Log.e("lock", "Lock has been released!");
                return regularQuery;
            }
        }
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }
    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

    private String getClientPort() {
        TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        String clientPort = String.valueOf(Integer.parseInt(portStr) * 2);
        return clientPort;
    }

    private String getClientId() {
        TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        return portStr;
    }

    private void writeToStorage(String key, String value) {
        // write key as file name and value as file content
        FileOutputStream os;
        try {
            os = getContext().openFileOutput(key, Context.MODE_PRIVATE);
            os.write(value.getBytes());
            os.close();

            Log.e("fileio", "INSERT: " + "key: " + key + " value: " + value);
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("fileio", "Cannot write file");
        }
    }

    private void deleteFromStorage(String selection) {
        for (String key : getContext().fileList()) {
            if (key.equals(selection)) {
                getContext().deleteFile(key);
                Log.e("fileio", "DELETE: " + "key: " + key);
            }
        }
    }

    private boolean deleteAllFromStorage() {
        for (String key : getContext().fileList()) {
            if (!getContext().deleteFile(key)) {
                return false;
            }
        }
        return true;
    }

    private Cursor hashMapToCursor(HashMap<String, String> map) {
        MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key", "value"});
        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            String key = pair.getKey().toString();
            String value = pair.getValue().toString();
            matrixCursor.addRow(new String[]{key, value});
            it.remove();
        }
        matrixCursor.moveToFirst();
        return matrixCursor;
    }
    private MatrixCursor queryAllFromStorage() {

        MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key", "value"});
        try {
            for (String key : getContext().fileList()) {
                StringBuilder sb = new StringBuilder();
                FileInputStream is = getContext().openFileInput(key);
                //get file content
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                //read first line of file
                String line;
                line = br.readLine();
                sb.append(line);
                // clean up
                br.close();
                isr.close();
                is.close();
                matrixCursor.addRow(new String[]{key, sb.toString()});
            }
            return matrixCursor;
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("fileio", "Cannot read file");
        }
        return null;
    }

    private MatrixCursor queryFromStorage(String key) {
        try {
            FileInputStream is = getContext().openFileInput(key);
            StringBuilder sb = new StringBuilder();
            //get file content
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            //read first line of file
            String line;
            line = br.readLine();
            sb.append(line);
            // clean up
            br.close();
            isr.close();
            is.close();
            // MatrixCursor
            MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key", "value"});
            matrixCursor.addRow(new String[]{key, sb.toString()});
            return matrixCursor;
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("fileio", "Cannot read file");
        }
        return null;
    }

    private HashMap<String, String> cursorToHashMap(Cursor cursor) {
        HashMap<String, String> map = new HashMap<String, String>();
        int keyIndex = cursor.getColumnIndex(KEY_FIELD);
        int valueIndex = cursor.getColumnIndex(VALUE_FIELD);
        if (cursor.moveToFirst()) {
            String key = cursor.getString(keyIndex);
            String value = cursor.getString(valueIndex);
            map.put(key, value);
            while (cursor.moveToNext()) {
                key = cursor.getString(keyIndex);
                value = cursor.getString(valueIndex);
                map.put(key, value);
            }
            return map;
        }

        return null;
    }

    private void print(Cursor cursor) {
        int keyIndex = cursor.getColumnIndex(KEY_FIELD);
        int valueIndex = cursor.getColumnIndex(VALUE_FIELD);
        Log.e("fileio", "Cursor count: " + cursor.getCount());

        cursor.moveToFirst();
        String key = cursor.getString(keyIndex);
        String value = cursor.getString(valueIndex);
        Log.e("fileio", "PRINT_QUERY: " + "key: " + key + " value: " + value);

        while (cursor.moveToNext()) {
            key = cursor.getString(keyIndex);
            value = cursor.getString(valueIndex);
            Log.e("fileio", "PRINT_QUERY: " + "key: " + key + " value: " + value);
        }
        cursor.moveToFirst();
    }
    private RoutingTable getTable() {
        return table;
    }

    public String getPartition(String key) {
        for (Tuple tuple : getTable().getTuples()) {
            if (isPartition(tuple.id, key)) {
                Log.e("partition", "Partition Found!: " + tuple.id);
                return tuple.port;
            }
        }
        Log.e("partition", "Partition Not Found :(");
        return null;
    }

    public String getRelativePredecessor(String id) {
        ArrayList<Tuple> tuples = getTable().getTuples();

        for (int i = 0; i < tuples.size(); i++) {
            Tuple tuple = tuples.get(i);

            if (id.equals(tuple.id)) {
                if (i - 1 >= 0) {
                    return tuples.get(i - 1).hash;
                } else {
                    return tuples.get(tuples.size() - 1).hash;
                }
            }
        }
        return null;

    }

    public String getRelativeSuccessor(String id) {
        ArrayList<Tuple> tuples = getTable().getTuples();

        for (int i = 0; i < tuples.size(); i++) {
            Tuple tuple = tuples.get(i);

            if (id.equals(tuple.id)) {
                if (i + 1 >= tuples.size()) {
                    return tuples.get(0).hash;
                } else {
                    return tuples.get(i + 1).hash;
                }
            }
        }
        return null;
    }

    public boolean isPartition(String id, String key) {
        try {
            String hashId = genHash(id);
            String hashKey = genHash(key);
            String max = getTable().getMax().hash;
            String min = getTable().getMin().hash;
            String predecessor = getRelativePredecessor(id);

            if (getTable().getCount() == 1) {
                return true;
            } else if (hashKey.compareTo(predecessor) > 0 && hashKey.compareTo(hashId) <= 0) {
                return true;
            } else if (hashKey.compareTo(max) > 0 && hashId.equals(min)) {
                return true;
            } else return hashKey.compareTo(min) < 0 && hashId.equals(min);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static class ClientTask extends AsyncTask<Request, Void, Void> {

        @Override
        protected Void doInBackground(Request... args) {
            Socket socket;
            ObjectOutputStream oos;
            try {
                Request request = args[0];
                //send out
                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(request.remote));
                socket.setSoTimeout(5000);
                //set output stream of socket to send message to server
                oos = new ObjectOutputStream(socket.getOutputStream());
                oos.writeObject(request);

                Thread.sleep(100);
            } catch (UnknownHostException e) {
                e.printStackTrace();
                Log.e(getClass().getSimpleName(), "ClientTask UnknownHostException");
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(getClass().getSimpleName(), "ClientTask socket IOException");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class ServerTask extends AsyncTask<ServerSocket, Request, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            Socket clientSocket = null;
            //refrence: https://docs.oracle.com/javase/7/docs/api/java/io/ObjectInputStream.html
            ObjectInputStream ois = null;
            try {
                //a while loop to handle multiple messages
                while (true) {
                    // server accepts connection from client
                    clientSocket = serverSocket.accept();
                    clientSocket.setSoTimeout(5000);
                    //get input stream from client socket
                    //read the input stream as data, in our case, as a String
                    ois = new ObjectInputStream(clientSocket.getInputStream());
                    //get Message from ObjectInputStream
                    final Request request = (Request) ois.readObject();
                    publishProgress(request);

                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(Request... requests) {
            Request request = requests[0];

            if (request.type.equals("INSERT")) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(KEY_FIELD, request.key);
                contentValues.put(VALUE_FIELD, request.value);
                insert(URI, contentValues);
            } else if (request.type.equals("DELETE")) {
                delete(URI, request.key, null);
            } else if (request.type.equals("DELETE_ALL")) {
                delete(URI, "*", null);
            } else if (request.type.equals("QUERY")) {
                Cursor cursor = query(URI, null, request.key, null, null, null);
                cursor.moveToFirst();
                int keyIndex = cursor.getColumnIndex(KEY_FIELD);
                int valueIndex = cursor.getColumnIndex(VALUE_FIELD);
                final String KEY = cursor.getString(keyIndex);
                final String VALUE = cursor.getString(valueIndex);
                Request reply = new Request(getClientPort(), request.origin, "QUERY_REPLY", KEY, VALUE, null, null);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, reply);
            } else if (request.type.equals("QUERY_REPLY")) {
                // MatrixCursor
                synchronized (lock) {
                    MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key", "value"});
                    matrixCursor.addRow(new String[]{request.key, request.value});
                    regularQuery = matrixCursor;
                    lock.notify();
                }
                Log.e("lock", "Lock has been notified!");

            } else if (request.type.equals("QUERY_ALL")) {
                if (!getClientPort().equals(request.origin)) {
                    Cursor query = queryAllFromStorage();
                    if (query != null) {
                        globalQuery = cursorToHashMap(query);
                    }
                    if (request.query != null) {
                        if (globalQuery != null) {
                            globalQuery.putAll(request.query);
                        } else {
                            globalQuery = new HashMap<String, String>(request.query);
                        }
                    }
                    final String REMOTE = getTable().getSuccessor().port;
                    Request reply = new Request(request.origin, REMOTE, "QUERY_ALL", null, null, null, globalQuery);
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, reply);
                } else {
                    synchronized (lock) {
                        Cursor query = queryAllFromStorage();
                        if (query != null) {
                            globalQuery = cursorToHashMap(query);
                        }
                        if (request.query != null) {
                            if (globalQuery != null) {
                                globalQuery.putAll(request.query);
                            } else {
                                globalQuery = new HashMap<String, String>(request.query);
                            }
                        }
                        lock.notify();
                    }
                    Log.e("gquery", "Release Global Query lock");
                }
            } else if (request.type.equals("JOIN_REQUEST")) {
                // exchange routing tables
                RoutingTable copy = request.table;
                getTable().join(copy);
                getTable().print();
                Request reply = new Request(getClientPort(), request.origin, "JOIN_REPLY", null, null, getTable(), null);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, reply);

            } else if (request.type.equals("JOIN_REPLY")) {
                RoutingTable copy = request.table;
                String remote;
                getTable().join(copy);
                getTable().print();
                remote = getTable().getPredecessor().port;
                Request reply = new Request(getClientPort(), remote, "UPDATE", null, null, getTable(), null);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, reply);
            } else if (request.type.equals("UPDATE")) {
                RoutingTable copy = request.table;
                String remote;
                synchronized (this) {
                    getTable().join(copy);
                    getTable().print();
                    remote = getTable().getPredecessor().port;
                }
                if (!getClientPort().equals(request.origin)) {
                    Request reply = new Request(request.origin, remote, "UPDATE", null, null, getTable(), null);
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, reply);
                }
            }
        }
    }
}
