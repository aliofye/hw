package edu.buffalo.cse.cse486586.simpledht;

import java.io.Serializable;

public class Tuple implements Comparable<Tuple>, Serializable {
    String id;
    String port;
    String hash;

    public Tuple(String id, String port, String hash) {
        this.id = id;
        this.port = port;
        this.hash = hash;
    }

    @Override
    public int compareTo(Tuple p) {
        return (this.hash.compareTo(p.hash));
    }
}
