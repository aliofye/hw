package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.Serializable;
import java.util.HashMap;

public class Request implements Serializable {
    public String origin;
    public String remote;
    public String type;
    public String key;
    public String value;
    public RoutingTable table;
    public HashMap<String, String> query;
    public int replicationCounter;


    public Request(String origin,
                   String remote,
                   String type,
                   String key,
                   String value,
                   RoutingTable table,
                   HashMap<String, String> query) {
        this.origin = origin;
        this.remote = remote;
        this.type = type;
        this.key = key;
        this.value = value;
        this.table = table;
        this.query = query;
        replicationCounter = 1;
    }
}
