package edu.buffalo.cse.cse486586.simpledynamo;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class RoutingTable implements Serializable {
    private String port;
    private ArrayList<Tuple> tuples;

    public RoutingTable(String port) {
        this.port = port;
        this.tuples = new ArrayList<Tuple>();
    }

    public void add(Tuple tuple) {
        if (!contains(tuple)) {
            this.tuples.add(tuple);
        }
        Collections.sort(this.tuples);
    }

    public void remove(Tuple tuple) {
        if (contains(tuple)) {
            this.tuples.remove(tuple);
        }
    }

    private boolean contains(Tuple tuple) {
        for (Tuple old : this.tuples) {
            if (old.port.equals(tuple.port)) {
                return true;
            }
        }
        return false;
    }

    public void print() {
        Log.e("ring", "TABLE");
        for (Tuple tuple : tuples) {
            Log.e("ring", tuple.port + "=>" + tuple.hash);
        }
    }

    public void join(RoutingTable copy) {
        for (Tuple tuple : copy.tuples) {
            this.add(tuple);
        }
    }

    public Tuple getMin() {
        return this.tuples.get(0);
    }

    public Tuple getMax() {
        return this.tuples.get(tuples.size() - 1);
    }

    public ArrayList<Tuple> getTuples() {
        return this.tuples;
    }

    public int getCount() {
        return this.tuples.size();
    }

    public String getPort() {
        return this.port;
    }

    public Tuple getPredecessor() {
        for (int i = 0; i < tuples.size(); i++) {
            Tuple tuple = tuples.get(i);

            if (this.port.equals(tuple.port)) {
                if (i - 1 >= 0) {
                    return tuples.get(i - 1);
                } else {
                    return tuples.get(tuples.size() - 1);
                }
            }
        }
        return null;
    }

    public String getId(String port) {
        for (Tuple tuple : this.getTuples()) {
            if (tuple.port.equals(port)) {
                return tuple.id;
            }
        }
        return null;
    }
    public Tuple getSuccessor() {
        for (int i = 0; i < tuples.size(); i++) {
            Tuple tuple = tuples.get(i);

            if (this.port.equals(tuple.port)) {
                if (i + 1 >= tuples.size()) {
                    return tuples.get(0);
                } else {
                    return tuples.get(i + 1);
                }
            }
        }
        return null;
    }
}
