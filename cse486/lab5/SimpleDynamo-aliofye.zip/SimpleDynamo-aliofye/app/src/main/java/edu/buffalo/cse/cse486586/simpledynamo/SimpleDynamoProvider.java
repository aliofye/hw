package edu.buffalo.cse.cse486586.simpledynamo;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SimpleDynamoProvider extends ContentProvider {
	private final String REMOTE_PORT0 = "11108";
	private final String REMOTE_PORT1 = "11112";
	private final String REMOTE_PORT2 = "11116";
	private final String REMOTE_PORT3 = "11120";
	private final String REMOTE_PORT4 = "11124";
	private final Uri URI = Uri.parse("content://edu.buffalo.cse.cse486586.simpledht.provider");
	private final String KEY_FIELD = "key";
	private final String VALUE_FIELD = "value";
	private static RoutingTable table;
	private static Cursor regularQuery;
	private static HashMap<String, String> globalQuery;
	private final Object READ_LOCK = new Object();
	private final Object WRITE_LOCK = new Object();
	private static final String RECOVERY = "RECOVERY";

	public void deleteRemote(String origin, String key) {
		deleteFromStorage(key);

		final String REMOTE = getTable().getSuccessor().port;
		Request request = new Request(origin, REMOTE, "DELETE_REPLICA", key, null, null, null);
		client(request);
	}
	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// if key lies between successor and predecessor nodes
		if (selection.equals("\"@\"") || selection.equals("@")) {
			deleteAllFromStorage();
		} else if (selection.equals("\"*\"") || selection.equals("*")) {
			if (deleteAllFromStorage()) {
				// send to successor
				final String ORIGIN = getClientPort();
				final String REMOTE = getTable().getSuccessor().port;
				Request request = new Request(ORIGIN, REMOTE, "DELETE_ALL", null, null, null, null);
				client(request);
			}
		} else {
			if (isPartition(getClientId(), selection)) {
				// Delete
				deleteFromStorage(selection);
				// Delete replica
				final String ORIGIN = getClientPort();
				final String REMOTE = getTable().getSuccessor().port;
				synchronized (WRITE_LOCK) {
					Request request = new Request(ORIGIN, REMOTE, "DELETE_REPLICA", selection, null, null, null);
					client(request);
					try {
						WRITE_LOCK.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			} else {
                // send to correct partition
				final String ORIGIN = getClientPort();
                final String REMOTE = getPartition(selection);
				synchronized (WRITE_LOCK) {
                    Request request = new Request(ORIGIN, REMOTE, "DELETE", selection, null, null, null);
					client(request);
                    try {
						WRITE_LOCK.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

			}
		}

		return 0;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	public void insertRemote(String origin, String key, String value) {
		writeToStorage(key, value);

		final String REMOTE = getTable().getSuccessor().port;
		Request request = new Request(origin, REMOTE, "INSERT_REPLICA", key, value, null, null);
		client(request);
	}
	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// Get key and value from ContentValues
		String key = values.getAsString("key");
		String value = values.getAsString("value");
		// If key lies between successor and predecessor nodes
		if (isPartition(getClientId(), key)) {
			// Store
			writeToStorage(key, value);
			// Replicate
			final String ORIGIN = getClientPort();
			final String REMOTE = getTable().getSuccessor().port;

			synchronized (WRITE_LOCK) {
				Request request = new Request(ORIGIN, REMOTE, "INSERT_REPLICA", key, value, null, null);
				client(request);
				try {
					Log.e("lock", "acquired insert lock");
					WRITE_LOCK.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			Log.e("lock", "released insert lock");
		} else {
			// Send to correct partition
			final String ORIGIN = getClientPort();
            final String REMOTE = getPartition(key);

			synchronized (WRITE_LOCK) {
				Request request = new Request(ORIGIN, REMOTE, "INSERT", key, value, null, null);
				client(request);
				try {
					Log.e("lock", "acquired insert lock");
					WRITE_LOCK.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			Log.e("lock", "released insert lock");
		}
		return uri;
	}

	private void recover() {
		SharedPreferences sharedPreferences = getContext().getSharedPreferences(RECOVERY, Context.MODE_PRIVATE);
		boolean isRecovery = sharedPreferences.getBoolean("recovery", false);
		if (!isRecovery) {
			// First time running
			sharedPreferences.edit().putBoolean("recovery", true).apply();
			Log.e("recover", "first time run");
		} else {
			// Get keys from predecessor
			final String REMOTE = getTable().getPredecessor().port;
			Request request = new Request(getClientPort(), REMOTE, "RECOVER_QUERY", null, null, null, globalQuery);
			client(request);
		}
	}
	@Override
	public boolean onCreate() {
		try {
			// execute ServerTask()
			final int SERVER_PORT = 10000;
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
			server(serverSocket);

			// generate hash and add to routing table
			table = new RoutingTable(getClientPort());
			try {
				// 5554
				String id ="5554";
				String hash = genHash(id);
				Tuple tuple = new Tuple(id, REMOTE_PORT0, hash);
				table.add(tuple);
				// 5556
				id ="5556";
				hash = genHash(id);
				tuple = new Tuple(id, REMOTE_PORT1, hash);
				table.add(tuple);
				// 5558
				id ="5558";
				hash = genHash(id);
				tuple = new Tuple(id, REMOTE_PORT2, hash);
				table.add(tuple);
				// 5560
				id ="5560";
				hash = genHash(id);
				tuple = new Tuple(id, REMOTE_PORT3, hash);
				table.add(tuple);
				// 5562
				id ="5562";
				hash = genHash(id);
				tuple = new Tuple(id, REMOTE_PORT4, hash);
				table.add(tuple);

				getTable().print();

			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}

		} catch (IOException e) {
			Log.e(getClass().getSimpleName(), "Server not operational");
		}
		// Recover
//		getContext().getSharedPreferences(RECOVERY, Context.MODE_PRIVATE).edit().clear().apply();
		recover();

		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		if (selection.equals("\"@\"") || selection.equals("@")) {
			Cursor query = queryAllFromStorage();
			Log.e("fileio", "Local Query");
			print(query);
			return query;
		} else if (selection.equals("\"*\"") || selection.equals("*")) {
			// send to successor
			final String ORIGIN = getClientPort();
			final String REMOTE = getTable().getSuccessor().port;
			// base case
			synchronized (READ_LOCK) {
				Request request = new Request(ORIGIN, REMOTE, "QUERY_ALL", null, null, null, globalQuery);
				client(request);
				try {
					READ_LOCK.wait();
					Log.e("lock", "Grabbing lock!");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			Cursor query = hashMapToCursor(globalQuery);
			Log.e("fileio", "Global Query");
			Log.e("lock", "Lock has been released!");
			print(query);
			return query;
		} else {
			if (isPartition(getClientId(), selection)) {
				return queryFromStorage(selection);
			} else {
				// send to successor
				final String ORIGIN = getClientPort();
				final String REMOTE = getPartition(selection);

				synchronized (READ_LOCK) {
					Request request = new Request(ORIGIN, REMOTE, "QUERY", selection, null, null, null);
					client(request);
					try {
						READ_LOCK.wait();
						Log.e("lock", "Grabbing lock!");
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				Log.e("fileio", "Regular Query");
				Log.e("lock", "Lock has been released!");
				return regularQuery;
			}
		}
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

	private String getClientPort() {
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		String clientPort = String.valueOf(Integer.parseInt(portStr) * 2);
		return clientPort;
	}

	private String getClientId() {
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		return portStr;
	}

	private void writeAllToStorage(HashMap<String, String> map) {
		Iterator it = map.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			writeToStorage(pair.getKey().toString(), pair.getValue().toString());
			it.remove();
		}
	}
	private void writeToStorage(String key, String value) {
		// write key as file name and value as file content
		FileOutputStream os;
		try {
			os = getContext().openFileOutput(key, Context.MODE_PRIVATE);
			os.write(value.getBytes());
			os.close();

			Log.e("fileio", "INSERT: " + "key: " + key + " value: " + value);
		} catch (IOException e) {
			e.printStackTrace();
			Log.e("fileio", "Cannot write file");
		}
	}

	private void deleteFromStorage(String selection) {
		for (String key : getContext().fileList()) {
			if (key.equals(selection)) {
				getContext().deleteFile(key);
				Log.e("fileio", "DELETE: " + "key: " + key);
			}
		}
	}

	private boolean deleteAllFromStorage() {
		for (String key : getContext().fileList()) {
			if (!getContext().deleteFile(key)) {
				return false;
			}
		}
		return true;
	}

	private Cursor hashMapToCursor(HashMap<String, String> map) {
		MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key", "value"});
		Iterator it = map.entrySet().iterator();
		while (it.hasNext()) {
			HashMap.Entry pair = (HashMap.Entry) it.next();
			String key = pair.getKey().toString();
			String value = pair.getValue().toString();
			matrixCursor.addRow(new String[]{key, value});
			it.remove();
		}
		matrixCursor.moveToFirst();
		return matrixCursor;
	}
	private MatrixCursor queryAllFromStorage() {

		MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key", "value"});
		try {
			for (String key : getContext().fileList()) {
				StringBuilder sb = new StringBuilder();
				FileInputStream is = getContext().openFileInput(key);
				//get file content
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr);
				//read first line of file
				String line;
				line = br.readLine();
				sb.append(line);
				// clean up
				br.close();
				isr.close();
				is.close();
				matrixCursor.addRow(new String[]{key, sb.toString()});
			}
			return matrixCursor;
		} catch (IOException e) {
			e.printStackTrace();
			Log.e("fileio", "Cannot read file");
		}
		return null;
	}

	private MatrixCursor queryFromStorage(String key) {
		try {
			FileInputStream is = getContext().openFileInput(key);
			StringBuilder sb = new StringBuilder();
			//get file content
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			//read first line of file
			String line;
			line = br.readLine();
			sb.append(line);
			// clean up
			br.close();
			isr.close();
			is.close();
			// MatrixCursor
			MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key", "value"});
			matrixCursor.addRow(new String[]{key, sb.toString()});
			return matrixCursor;
		} catch (IOException e) {
			e.printStackTrace();
			Log.e("fileio", "Cannot read file");
		}
		return null;
	}

	private HashMap<String, String> cursorToHashMap(Cursor cursor) {
		HashMap<String, String> map = new HashMap<String, String>();
		int keyIndex = cursor.getColumnIndex(KEY_FIELD);
		int valueIndex = cursor.getColumnIndex(VALUE_FIELD);
		if (cursor.moveToFirst()) {
			String key = cursor.getString(keyIndex);
			String value = cursor.getString(valueIndex);
			map.put(key, value);
			while (cursor.moveToNext()) {
				key = cursor.getString(keyIndex);
				value = cursor.getString(valueIndex);
				map.put(key, value);
			}
			return map;
		}

		return null;
	}

	private void print(Cursor cursor) {
		int keyIndex = cursor.getColumnIndex(KEY_FIELD);
		int valueIndex = cursor.getColumnIndex(VALUE_FIELD);
		Log.e("fileio", "Cursor count: " + cursor.getCount());

		cursor.moveToFirst();
		String key = cursor.getString(keyIndex);
		String value = cursor.getString(valueIndex);
		Log.e("fileio", "PRINT_QUERY: " + "key: " + key + " value: " + value);

		while (cursor.moveToNext()) {
			key = cursor.getString(keyIndex);
			value = cursor.getString(valueIndex);
			Log.e("fileio", "PRINT_QUERY: " + "key: " + key + " value: " + value);
		}
		cursor.moveToFirst();
	}
	private RoutingTable getTable() {
		return table;
	}

	public String getPartition(String key) {
		for (Tuple tuple : getTable().getTuples()) {
			if (isPartition(tuple.id, key)) {
				Log.e("partition", "Partition Found!: " + tuple.id);
				return tuple.port;
			}
		}
		Log.e("partition", "Partition Not Found :(");
		return null;
	}

	public Tuple getRelativePredecessor(String id) {
		ArrayList<Tuple> tuples = getTable().getTuples();

		for (int i = 0; i < tuples.size(); i++) {
			Tuple tuple = tuples.get(i);

			if (id.equals(tuple.id)) {
				if (i - 1 >= 0) {
					return tuples.get(i - 1);
				} else {
					return tuples.get(tuples.size() - 1);
				}
			}
		}
		return null;

	}

	public Tuple getRelativeSuccessor(String id) {
		ArrayList<Tuple> tuples = getTable().getTuples();

		for (int i = 0; i < tuples.size(); i++) {
			Tuple tuple = tuples.get(i);

			if (id.equals(tuple.id)) {
				if (i + 1 >= tuples.size()) {
					return tuples.get(0);
				} else {
					return tuples.get(i + 1);
				}
			}
		}
		return null;

	}
	public boolean isPartition(String id, String key) {
		try {
			String hashId = genHash(id);
			String hashKey = genHash(key);
			String max = getTable().getMax().hash;
			String min = getTable().getMin().hash;
			String predecessor = getRelativePredecessor(id).hash;

			if (getTable().getCount() == 1) {
				return true;
			} else if (hashKey.compareTo(predecessor) > 0 && hashKey.compareTo(hashId) <= 0) {
				return true;
			} else if (hashKey.compareTo(max) > 0 && hashId.equals(min)) {
				return true;
			} else return hashKey.compareTo(min) < 0 && hashId.equals(min);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return false;
		}
	}
	private void client(final Request request){
		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				Socket socket;
				ObjectOutputStream oos;
				try {
					//send out
					socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
							Integer.parseInt(request.remote));
					socket.setSoTimeout(500);
					//set output stream of socket to send message to server
					oos = new ObjectOutputStream(socket.getOutputStream());
					oos.flush();
					Thread.sleep(100);
					oos.writeObject(request);
					oos.close();
					socket.close();
				} catch (Exception e) {
					if (request.type.equals("INSERT")) {
						Log.e("failure", "case: I cannot insert");
						final String ID = getTable().getId(request.remote);
						final String REMOTE = getRelativeSuccessor(ID).port;
						Log.e("failure", "forward to remote port: " + REMOTE + " instead of: " + request.remote);
						Request handler = new Request(request.origin, REMOTE, "INSERT_REPLICA", request.key, request.value, null, null);
						client(handler);
					} else {
						Log.e("failure", "case: I cannot replicate");
						if (request.replicationCounter == 1) {
							Log.e("failure", "subcase: 1st replicant is dead");
							final String ID = getTable().getId(request.remote);
							final String REMOTE = getRelativeSuccessor(ID).port;
							Log.e("failure", "forward to remote port: " + REMOTE + " instead of: " + request.remote);
							Request handler = new Request(request.origin, REMOTE, "INSERT_REPLICA", request.key, request.value, null, null);
							handler.replicationCounter++;
							client(handler);
						} else {
							Log.e("failure", "subcase: 2nd replicant is dead");
							Request handler = new Request(getClientPort(), request.origin, "INSERT_REPLY", null, null, null, null);
							client(handler);
						}
					}
				}
			}
		});
		thread.start();
	}
	private void server(final ServerSocket serverSocket){
		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				Socket clientSocket = null;
				ObjectInputStream ois = null;
				try {
					//a while loop to handle multiple messages
					while (true) {
						// server accepts connection from client
						clientSocket = serverSocket.accept();
						//get input stream from client socket
						//read the input stream as data, in our case, as a String
						ois = new ObjectInputStream(clientSocket.getInputStream());
						//get Message from ObjectInputStream
						final Request request = (Request) ois.readObject();
						ois.close();
						clientSocket.close();

						if (request.type.equals("INSERT")) {
							insertRemote(request.origin, request.key, request.value);
						} else if (request.type.equals("INSERT_REPLY")) {
							synchronized (WRITE_LOCK) {
								WRITE_LOCK.notify();
							}
						} else if (request.type.equals("INSERT_REPLICA")) {
							Log.e("replicate", "replication degree: " + request.replicationCounter);
							if (request.replicationCounter == 1) {
								if (request.origin.equals(getClientPort())) {
									synchronized (WRITE_LOCK) {
										WRITE_LOCK.notify();
									}
								}
								writeToStorage(request.key, request.value);
								Request forward = new Request(request.origin, getTable().getSuccessor().port, "INSERT_REPLICA", request.key, request.value, null, null);
								forward.replicationCounter = ++request.replicationCounter;
								client(forward);
							} else {
								//reply to orignal node
								if (request.origin.equals(getClientPort())) {
									synchronized (WRITE_LOCK) {
										WRITE_LOCK.notify();
									}
								}
								writeToStorage(request.key, request.value);
								Log.e("replicate", "finished");
								Request reply = new Request(getClientPort(), request.origin, "INSERT_REPLY", null, null, null, null);
								client(reply);
							}
						} else if (request.type.equals("DELETE")) {
							deleteRemote(request.origin, request.key);
						} else if (request.type.equals("DELETE_REPLY")) {
							synchronized (WRITE_LOCK) {
								WRITE_LOCK.notify();
							}
						} else if (request.type.equals("DELETE_REPLICA")) {
							if (request.replicationCounter == 1) {
								deleteFromStorage(request.key);
								Request forward = new Request(request.origin, getTable().getSuccessor().port, "DELETE_REPLICA", request.key, request.value, null, null);
								forward.replicationCounter = ++request.replicationCounter;
								client(forward);
								Log.e("replicate", forward.replicationCounter + "");
							} else {
								//reply to orignal node
								deleteFromStorage(request.key);
								Log.e("replicate", "finished");
								Request reply = new Request(getClientPort(), request.origin, "DELETE_REPLY", null, null, null, null);
								client(reply);
							}
						} else if (request.type.equals("DELETE_ALL")) {
							delete(URI, "*", null);
						} else if (request.type.equals("QUERY")) {
							Cursor cursor = query(URI, null, request.key, null, null, null);
							cursor.moveToFirst();
							int keyIndex = cursor.getColumnIndex(KEY_FIELD);
							int valueIndex = cursor.getColumnIndex(VALUE_FIELD);
							final String KEY = cursor.getString(keyIndex);
							final String VALUE = cursor.getString(valueIndex);
							Request reply = new Request(getClientPort(), request.origin, "QUERY_REPLY", KEY, VALUE, null, null);
							client(reply);
						} else if (request.type.equals("QUERY_REPLY")) {
							// MatrixCursor
							synchronized (READ_LOCK) {
								MatrixCursor matrixCursor = new MatrixCursor(new String[]{"key", "value"});
								matrixCursor.addRow(new String[]{request.key, request.value});
								regularQuery = matrixCursor;
								READ_LOCK.notify();
							}
							Log.e("lock", "Lock has been notified!");

						} else if (request.type.equals("RECOVER_QUERY")) {
							Cursor query = queryAllFromStorage();
							HashMap<String, String> queryMap;
							if (query != null) {
								queryMap = cursorToHashMap(query);
								if (queryMap != null) {
									Log.e("recover", "asking for keys, query returned: " + queryMap.size());
									Request reply = new Request(getClientPort(), request.origin, "RECOVER_REPLY", null, null, null, queryMap);
									client(reply);
								}
							}
						} else if (request.type.equals("RECOVER_REPLY")) {
							Log.e("recover", "recovery is finished, query returned: " + request.query.size());
							writeAllToStorage(request.query);
						} else if (request.type.equals("QUERY_ALL")) {
							if (!getClientPort().equals(request.origin)) {
								Cursor query = queryAllFromStorage();
								if (query != null) {
									globalQuery = cursorToHashMap(query);
								}
								if (request.query != null) {
									if (globalQuery != null) {
										globalQuery.putAll(request.query);
									} else {
										globalQuery = new HashMap<String, String>(request.query);
									}
								}
								final String REMOTE = getTable().getSuccessor().port;
								Request reply = new Request(request.origin, REMOTE, "QUERY_ALL", null, null, null, globalQuery);
								client(reply);
							} else {
								synchronized (READ_LOCK) {
									Cursor query = queryAllFromStorage();
									if (query != null) {
										globalQuery = cursorToHashMap(query);
									}
									if (request.query != null) {
										if (globalQuery != null) {
											globalQuery.putAll(request.query);
										} else {
											globalQuery = new HashMap<String, String>(request.query);
										}
									}
									READ_LOCK.notify();
								}
								Log.e("gquery", "Release Global Query lock");
							}
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		});
		thread.start();
	}
}
