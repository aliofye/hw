/**
 * @file xc.h
 * The XINU standard C Library, libxc.
 *
 * $Id: xc.h 221 2007-07-11 18:45:46Z mschul $
 */
/* Embedded XINU, Copyright (C) 2007.  All rights reserved. */

#include <vararg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
